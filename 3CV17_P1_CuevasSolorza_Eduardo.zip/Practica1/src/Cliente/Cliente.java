/*Eduardo Cuevas Solorza
  Aplicaciones para Comunicaciones en Red
  Programa: CARRITO DE COMPRAS
  CLIENTE
 */
package Cliente;

import java.net.*;
import java.io.*;
import Productos.Productos;
import Productos.ProductosV;
import java.util.List;
import java.util.ArrayList;

public class Cliente {

    ProductosV[] pv;
    static Socket cl;
    DataOutputStream dos;

    public static void main(String[] args) {
        Conexion c = new Conexion();
        c.setVisible(true);
    }
/*************************************************************************************************************/
    /*Bloque de codigo para iniciar la conexión con el servidor*/
    public void iniciar_conexion(String host, int port) {
        try {
            cl = new Socket(host, port);
            dos = new DataOutputStream(cl.getOutputStream());
            descargar_catalogo();
        } catch (Exception e) {
        }

    }
/*************************************************************************************************************/
    /*Bloque de codigo para recibir las imagenes para el catalogo y los productos*/
    public void descargar_catalogo() {
        try {

            DataInputStream dis = new DataInputStream(cl.getInputStream());
            int num_imagenes = dis.readInt();
            for (int i = 0; i < num_imagenes; i++) {
                byte[] b = new byte[1024];
                String nombre = dis.readUTF();
                long tam = dis.readLong();
                DataOutputStream dos = new DataOutputStream
                (new FileOutputStream(new File("Cliente/" + nombre)));
                long recibidos = 0;
                int porcentaje, n;
                while (recibidos < tam) {
                    n = dis.read(b);
                    dos.flush();
                    dos.write(b, 0, n);
                    dos.flush();
                    recibidos = recibidos + n;
                    porcentaje = (int) (recibidos * 100 / tam);
                    dos.flush();
                }
                dos.close();
            }
        } catch (Exception e) {
        }
        /*Obtener los productos y serializar para los que son vendidos */
        Productos[] p = ver_productos();
        pv = new ProductosV[6];
        pv[0] = new ProductosV(p[0].getNombre(), 0, p[0].getPrecio());
        pv[1] = new ProductosV(p[1].getNombre(), 0, p[1].getPrecio());
        pv[2] = new ProductosV(p[2].getNombre(), 0, p[2].getPrecio());
        pv[3] = new ProductosV(p[3].getNombre(), 0, p[3].getPrecio());
        pv[4] = new ProductosV(p[4].getNombre(), 0, p[4].getPrecio());
        pv[5] = new ProductosV(p[5].getNombre(), 0, p[5].getPrecio());
        try {
            ObjectOutputStream oos = new ObjectOutputStream
            (new FileOutputStream("Cliente/productos_vendidos.txt"));
            oos.writeObject(pv);
            oos.close();
        } catch (Exception e) {
        }
    }
/*************************************************************************************************************/
    /*Bloque para leer los productos que son enviados por el servidor*/
    public Productos[] ver_productos() {
        Productos[] productos;
        try {
            ObjectInputStream ois = new ObjectInputStream
            (new FileInputStream("Cliente/productos_serializados.txt"));
            productos = (Productos[]) ois.readObject();
            ois.close();
            return productos;
        } catch (Exception e) {
        }
        return null;
    }
/*************************************************************************************************************/
    /*Bloque para serializar los producto elegidos para le venta*/
    public ProductosV[] productos_vendidos() {
        ProductosV[] pv;
        try {
            ObjectInputStream ois = new ObjectInputStream
            (new FileInputStream("Cliente/productos_vendidos.txt"));
            pv = (ProductosV[]) ois.readObject();
            ois.close();
            return pv;
        } catch (Exception e) {
        }
        return null;
    }
/*************************************************************************************************************/
    /*Bloque para serializar los productos que se van a comprar*/
    public void productos_vendidos_s(ProductosV pv, int index) {

        ProductosV[] pvs = productos_vendidos();
        pvs[index].setCantidad(pvs[index].getCantidad() + pv.getCantidad());
        System.out.println(pv.getCantidad());
        try {
            ObjectOutputStream oos = new ObjectOutputStream
            (new FileOutputStream("Cliente/productos_vendidos.txt"));
            oos.writeObject(pvs);

            oos.close();
        } catch (Exception e) {
        }
    }
    public void producto_vendido(ProductosV[] pv) {

        try {
            ObjectOutputStream oos = new ObjectOutputStream
            (new FileOutputStream("Cliente/productos_vendidos.txt"));
            oos.writeObject(pv);

            oos.close();
        } catch (Exception e) {
        }
    }
/*************************************************************************************************************/
    /*Bloque para actualizar las existencias */
    public void actualizar_productos(ProductosV pv, int index) {
        Productos [] p = ver_productos();
        p[index].setExistencias(p[index].getExistencias()- pv.getCantidad()); 
         try {
            ObjectOutputStream oos = new ObjectOutputStream
            (new FileOutputStream("Cliente/productos_serializados.txt"));
            oos.writeObject(p);

            oos.close();
        } catch (Exception e) {
        }
    }
/*************************************************************************************************************/
    /*Bloque para registrar la compra y envio de archivos para 
      que el servidor actualice las existencias en su base*/
    public void registrar_compra() {
        try {
            File [] f = new File[2];
            f[0] = new File ("Cliente/productos_serializados.txt");
            f[1] = new File ("Cliente/productos_vendidos.txt");
            DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
            dos.writeInt(1);
            dos.flush();
            for(File a: f){
                String archivo = a.getAbsolutePath();
                String nombre = a.getName();
                long tam = a.length();
                DataInputStream dis = new DataInputStream
                (new FileInputStream(archivo));
                dos.writeUTF(nombre);
                dos.flush();
                byte[] b = new byte[1024];
                long enviados = 0;
                int porcentaje, n;
                dos.writeLong(tam);
                dos.flush();
                while (enviados < tam) {
                    n = dis.read(b);
                    dos.flush();
                    dos.write(b, 0, n);
                    dos.flush();
                    enviados = enviados + n;
                    porcentaje = (int) (enviados * 100 / tam);
                    dos.flush();
                }
                dis.close();
            }
            limpiar_productos();
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
/*************************************************************************************************************/
    /*Bloque para limpiar los objetos de los productos vendidos */
    public void limpiar_productos(){
        ProductosV[] v = productos_vendidos();
        int aux = 0;
        for(ProductosV pv : v){
            if(pv.getCantidad() != 0){
                pv.setCantidad(0);
            }
        }
        producto_vendido(v);
    }
/*************************************************************************************************************/
    /*Bloque para obtener una lista de los productos vendidos para el reporte*/
    public List obtener_productos(){
        ProductosV[] v = productos_vendidos();
        ArrayList <ProductosV> lista = new ArrayList <>();
        for(ProductosV pv : v){
            if(pv.getCantidad() != 0){
                lista.add(pv);
            }
        }
        return lista;
    }
/*************************************************************************************************************/
    /*Bloque para obtener el total de la compra*/
    public float obtener_total(){
        float total = 0;
        ProductosV[] v = productos_vendidos();
        for(ProductosV pv : v){
            if(pv.getCantidad() != 0){
                total = total + pv.getCantidad()*pv.getPrecio();
            }
        }
        return total;
    }
/*************************************************************************************************************/
    /*Bloque para cerrar la conexion con el servidor*/
    public void cerrar_conexion() {
        try {
            DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
            dos.writeInt(2);
            dos.flush();

            dos.close();
            this.dos.close();
            cl.close();
        } catch (Exception e) {

        }
    }
}
/*************************************************************************************************************/