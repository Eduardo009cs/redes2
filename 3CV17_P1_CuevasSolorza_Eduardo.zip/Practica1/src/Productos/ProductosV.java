/*Eduardo Cuevas Solorza
  Aplicaciones para Comunicaciones en Red
  Programa: CARRITO DE COMPRAS
  Productos Vendidos
*/
/*
    Clase donde se almacenan los productos que seran vendidos implementando 
    la interfaz serializable  
*/
package Productos;

import java.io.Serializable;

public class ProductosV implements Serializable {
    String nombre;
    int cantidad;
    float precio;

    public ProductosV(String nombre, int cantidad, float precio) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getCantidad() {
        return cantidad;
    }
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    public float getPrecio() {
        return precio;
    }
    public void setPrecio(float precio) {
        this.precio = precio;
    }
}
