/*Eduardo Cuevas Solorza
  Aplicaciones para Comunicaciones en Red
  Programa: CARRITO DE COMPRAS
  SERVIDOR
 */
package Servidor;

import java.net.*;
import java.io.*;
import Productos.Productos;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Servidor {

    static Socket cl;
    static DataInputStream dis;
    static DataOutputStream dos;
    static ServerSocket s; 

    public static void main(String[] args) {
        try {
            Productos[] p = iniciar_productos();
            serializar(p);
            s = new ServerSocket(3070);
            
            iniciar_conexion();
        } catch (Exception e) {
        }
    }
/*************************************************************************************************************/
    /*Bloque que inicia la conexion con el cliente*/
    public static void iniciar_conexion(){
        try {
            System.out.println("Esperando...");
            for (;;) {
                cl = s.accept();
                System.out.println("Conexión establecida desde " 
                        + cl.getInetAddress() + ":" + cl.getPort());
                envio_catalogo();
                dis = new DataInputStream(cl.getInputStream());
                esperando();
            }
        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
/*************************************************************************************************************/
    /*Bloque que inicializa los productos*/
    public static Productos[] iniciar_productos() {
        Productos[] producto = new Productos[6];
        producto[0] = new Productos(1, "Xiaomi Poco X3", 5899, 
                "Pantalla de 6,67 pulgadas.Camara Cuadruple.Bateria 5160 mAh", 5);
        producto[1] = new Productos(2, "Samsung A52", 7848, 
                "Pantalla de 6,5 pulgadas.FHD+ Super AMOLED Infinity-O.Display de 90Hz", 14);
        producto[2] = new Productos(3, "Samsung A71", 9499, 
                "Cámara frontal 32MP.Pantalla Infinity-O de 6,7.Batería de 4,500 mAh", 27);
        producto[3] = new Productos(4, "Xiaomi Redmi Note 10", 6199, 
                "Pantalla de 6,67 pulgadas.Memoria RAM 6GB.Batería de 5,020 mah", 9);
        producto[4] = new Productos(5, "iPhone 11", 12999, 
                "Pantalla de 6,1 pulgadas.Sistema operativo iOS 13.Resolución de 1792 x 828", 4);
        producto[5] = new Productos(6, "Samsung A32", 5996, 
                "Pantalla de 6,4 pulgadas.Cámara 64+8+5+5 MP.Batería de 5,000 mAh con carga rápida", 33);
        return producto;
    }
/*************************************************************************************************************/
    /*Bloque para el envio del catalogo al cliente*/
    public static void envio_catalogo() {
        final File archivos = new File("Servidor");
        File[] l = archivos.listFiles();
        try {
            dos = new DataOutputStream(cl.getOutputStream());
            dos.writeInt(l.length);
            dos.flush();
            for (final File archivo_entrada : archivos.listFiles()) {
                if (!archivo_entrada.isDirectory()) {
                    String archivo = archivo_entrada.getAbsolutePath();
                    String nombre = archivo_entrada.getName();
                    long tam = archivo_entrada.length();
                    DataInputStream dis = new DataInputStream
                        (new FileInputStream(archivo));
                    dos.writeUTF(nombre);
                    dos.flush();
                    byte[] b = new byte[1024];
                    long enviados = 0;
                    int porcentaje, n;
                    dos.writeLong(tam);
                    dos.flush();
                    while (enviados < tam) {
                        n = dis.read(b);
                        dos.flush();
                        dos.write(b, 0, n);
                        dos.flush();
                        enviados = enviados + n;
                        porcentaje = (int) (enviados * 100 / tam);
                        dos.flush();
                    }
                    dis.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
/*************************************************************************************************************/
    /*Bloque para serializar los productos, si ya fue creado no realiza nada*/
    public static void serializar(Productos[] producto) {
        File f = new File("Servidor/productos_serializados.txt");
        if(!f.exists()){
            try {
                ObjectOutputStream oos = new ObjectOutputStream
                    (new FileOutputStream("Servidor/productos_serializados.txt"));
                oos.writeObject(producto);
                oos.reset();
                oos.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
/*************************************************************************************************************/
    /*Registra la compra del cliente, actualiza las existencias*/
    public static void registrar_compra() {
        try {
            for (int i = 0; i < 2; i++) {
                byte[] b = new byte[1024];
                String nombre = dis.readUTF();
                System.out.println(nombre);
                long tam = dis.readLong();
                System.out.println(tam);
                DataOutputStream dos = new DataOutputStream
                (new FileOutputStream(new File("Servidor/" + nombre)));
                long recibidos = 0;
                int porcentaje, n;
                while (recibidos < tam) {       
                    n = dis.read(b, 0,(int)tam);
                    System.out.println(n);
                    dos.flush();
                    dos.write(b, 0, n);
                    dos.flush();
                    recibidos = recibidos + n;
                    porcentaje = (int) (recibidos * 100 / tam);
                    dos.flush();       
                }
                dos.close();   
            }
            esperando();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
/*************************************************************************************************************/
    /*Bloque para esperar una respuesta del cliente*/
    public static void esperando() {
        int opt = 0;
        try {
            while (opt == 0) {
                dis = new DataInputStream(cl.getInputStream());
                opt = dis.readInt();
            }
            switch (opt) {
                case 1 -> registrar_compra();
                case 2 ->{
                    dis.close();
                    dos.close();
                    cl.close();
                    borrar_datos();
                    iniciar_conexion();
                }
                default -> {
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);

        }
    }
/*************************************************************************************************************/
    /*Bloque para borrar los datos de los productos vendidos*/
    public static void borrar_datos(){
        File f = new File("Servidor/productos_vendidos.txt");
        f.delete();
    }
}
